package com.example.mapacustos

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.lifecycle.lifecycleScope
import com.example.mapacustos.ui.pantalla.LoginScreen
import com.example.mapacustos.ui.pantalla.RegisterScreen
import com.example.mapacustos.ui.pantalla.PanelPerformanceScreen
import com.example.mapacustos.ui.datos.Routes
import com.example.mapacustos.ui.pantalla.SoundColorSettingsScreen
import com.example.mapacustos.ui.datos.AppDatabase
import com.example.mapacustos.ui.datos.DatabaseInitializer
import com.example.mapacustos.ui.pantalla.UserSettingsScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestPermissionsIfNeeded()

        // 🔥 INICIALIZAR BASE DE DATOS Y CARGAR JSON SI ESTÁ VACÍA
        val db = AppDatabase.getDatabase(this)

        lifecycleScope.launch {

            DatabaseInitializer.loadJsonIfEmpty(
                context = this@MainActivity,
                dao = db.streetDao()
            )

            val count = db.streetDao().countStreets()
            println("DEBUG_CALLES: $count")
        }

        setContent {

            val navController = rememberNavController()

            Surface(color = MaterialTheme.colorScheme.background) {

                NavHost(
                    navController = navController,
                    startDestination = Routes.LOGIN
                ) {

                    composable(Routes.LOGIN) {
                        LoginScreen(
                            onLoginSuccess = {
                                navController.navigate(Routes.MAP) {
                                    popUpTo(Routes.LOGIN) { inclusive = true }
                                }
                            },
                            onCreateAccountClick = {
                                navController.navigate(Routes.REGISTER)
                            }
                        )
                    }

                    composable(Routes.REGISTER) {
                        RegisterScreen(
                            onAlreadyHaveAccountClick = {
                                navController.popBackStack()
                            },
                            onRegisterSuccess = {
                                navController.navigate(Routes.MAP) {
                                    popUpTo(Routes.LOGIN) { inclusive = true }
                                }
                            }
                        )
                    }

                    composable(Routes.MAP) {
                        PanelPerformanceScreen(navController)
                    }

                    composable("soundSettings") {
                        SoundColorSettingsScreen(navController)
                    }

                    composable("userSettings") {
                        UserSettingsScreen(navController)
                    }

                }
            }
        }
    }

    private fun requestPermissionsIfNeeded() {

        val permissions = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (permissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissions.toTypedArray(),
                1001
            )
        }
    }
}