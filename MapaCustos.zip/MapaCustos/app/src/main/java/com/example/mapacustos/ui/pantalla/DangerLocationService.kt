package com.example.mapacustos.ui.pantalla

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.Vibrator
import androidx.annotation.RequiresPermission
import androidx.core.app.NotificationCompat
import com.example.mapacustos.ui.datos.AppDatabase
import com.google.android.gms.location.*
import org.osmdroid.util.GeoPoint
import kotlinx.coroutines.*
import com.example.mapacustos.ui.datos.StreetEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
class DangerLocationService : Service() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val serviceScope = CoroutineScope(Dispatchers.Default)

    private lateinit var database: AppDatabase
    private var lastAlertStreet: String? = null

    @RequiresPermission(allOf = [Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION])
    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getDatabase(applicationContext)

        fusedLocationClient =
            LocationServices.getFusedLocationProviderClient(this)

        startForegroundNotification()
        startLocationUpdates()
    }

    private fun startForegroundNotification() {

        val channelId = "danger_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Zona peligrosa",
                NotificationManager.IMPORTANCE_HIGH
            )

            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Protección activa")
            .setContentText("Monitoreando zonas peligrosas")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .build()

        startForeground(1, notification)
    }

    @RequiresPermission(allOf = [Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION])
    private fun startLocationUpdates() {

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val request = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            5000L
        ).build()

        fusedLocationClient.requestLocationUpdates(
            request,
            locationCallback,
            Looper.getMainLooper()
        )
    }

    private val locationCallback =
        object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {

                val location = result.lastLocation ?: return

                val current = GeoPoint(
                    location.latitude,
                    location.longitude
                )

                checkDangerZone(current)
            }
        }

    private fun checkDangerZone(current: GeoPoint) {

        serviceScope.launch {

            val streets = database.streetDao().getAllStreets()

            for (street in streets) {

                if (street.dangerLevel == 0) continue

                val points = geoJsonToGeoPoints(street.geoJson)

                for (point in points) {

                    val distance = current.distanceToAsDouble(point)

                    // 🔥 radio de activación en metros
                    if (distance < 25.0) {

                        // Evitar repetir alerta constantemente
                        if (lastAlertStreet == street.name) return@launch

                        lastAlertStreet = street.name

                        withContext(Dispatchers.Main) {
                            triggerAlert(street)
                        }

                        return@launch
                    }
                }
            }

            // Si no está en ninguna calle peligrosa
            lastAlertStreet = null
        }
    }

    private fun triggerAlert(street: StreetEntity) {

        val manager = getSystemService(NotificationManager::class.java)

        val notification = NotificationCompat.Builder(this, "danger_channel")
            .setContentTitle("⚠ Zona peligrosa")
            .setContentText("Estás en: ${street.name} (Nivel ${street.dangerLevel})")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        manager.notify(2, notification)

        // Vibración simple
        val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        vibrator.vibrate(500)
    }
    private fun geoJsonToGeoPoints(geoJson: String): List<GeoPoint> {

        val points = mutableListOf<GeoPoint>()

        val cleaned = geoJson
            .replace("[", "")
            .replace("]", "")

        val pairs = cleaned.split(",")

        for (i in pairs.indices step 2) {
            try {
                val lon = pairs[i].trim().toDouble()
                val lat = pairs[i + 1].trim().toDouble()
                points.add(GeoPoint(lat, lon))
            } catch (_: Exception) { }
        }

        return points
    }
    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}