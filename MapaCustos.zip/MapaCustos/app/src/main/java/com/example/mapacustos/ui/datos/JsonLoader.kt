package com.example.mapacustos.ui.datos

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

object DatabaseInitializer {
    suspend fun loadJsonIfEmpty(context: Context, dao: StreetDao) {

        if (dao.getAllStreets().isNotEmpty()) return

        withContext(Dispatchers.IO) {

            val inputStream = context.assets.open("export.json")
            val jsonString = inputStream.bufferedReader().use { it.readText() }

            val root = JSONObject(jsonString)
            val elements = root.getJSONArray("elements")

            // 1️⃣ Guardar todos los nodos
            val nodesMap = mutableMapOf<Long, Pair<Double, Double>>()

            for (i in 0 until elements.length()) {
                val obj = elements.getJSONObject(i)

                if (obj.getString("type") == "node") {
                    val id = obj.getLong("id")
                    val lat = obj.getDouble("lat")
                    val lon = obj.getDouble("lon")

                    nodesMap[id] = Pair(lat, lon)
                }
            }

            // 2️⃣ Procesar las calles (ways)
            for (i in 0 until elements.length()) {

                val obj = elements.getJSONObject(i)

                if (obj.getString("type") == "way") {

                    val tags = obj.optJSONObject("tags") ?: continue
                    val name = tags.optString("name", null) ?: continue

                    val nodeIds = obj.getJSONArray("nodes")

                    val coordinatesArray = JSONArray()

                    for (j in 0 until nodeIds.length()) {
                        val nodeId = nodeIds.getLong(j)

                        val latLon = nodesMap[nodeId] ?: continue

                        val pair = JSONArray()
                        pair.put(latLon.second) // lon
                        pair.put(latLon.first)  // lat

                        coordinatesArray.put(pair)
                    }

                    if (coordinatesArray.length() == 0) continue

                    val geoJsonObject = JSONObject()
                    geoJsonObject.put("type", "LineString")
                    geoJsonObject.put("coordinates", coordinatesArray)

                    val street = StreetEntity(
                        name = name,
                        geoJson = geoJsonObject.toString(),
                        dangerLevel = 0,
                        includesViolation = false,
                        includesViolence = false
                    )

                    dao.insertStreet(street)
                }
            }

            println("Calles insertadas correctamente")
        }
    }
}