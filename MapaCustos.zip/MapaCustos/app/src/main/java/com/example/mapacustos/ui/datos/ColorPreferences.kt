package com.example.mapacustos.ui.datos

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("color_settings")

object ColorPreferences {

    private val COLOR_L1 = stringPreferencesKey("color_l1")
    private val COLOR_L2 = stringPreferencesKey("color_l2")
    private val COLOR_L3 = stringPreferencesKey("color_l3")

    suspend fun saveColors(
        context: Context,
        l1: String,
        l2: String,
        l3: String
    ) {
        context.dataStore.edit {
            it[COLOR_L1] = l1
            it[COLOR_L2] = l2
            it[COLOR_L3] = l3
        }
    }

    fun getColors(context: Context): Flow<Triple<String, String, String>> {
        return context.dataStore.data.map {
            Triple(
                it[COLOR_L1] ?: "#FFFF00",
                it[COLOR_L2] ?: "#FFA500",
                it[COLOR_L3] ?: "#FF0000"
            )
        }
    }
}