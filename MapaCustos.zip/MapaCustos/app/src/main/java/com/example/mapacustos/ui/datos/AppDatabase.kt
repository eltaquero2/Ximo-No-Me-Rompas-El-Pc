package com.example.mapacustos.ui.datos

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.mapacustos.data.UserDao

@Database(
    entities = [
        StreetEntity::class,
        UserEntity::class
    ],
    version = 4,   // 👈 IMPORTANTE
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun streetDao(): StreetDao
    abstract fun userDao(): UserDao

    companion object {

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {

                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mapa_database"
                )
                    .fallbackToDestructiveMigration() // 👈 SOLO ESTO
                    .build()

                INSTANCE = instance
                instance
            }
        }
    }
}