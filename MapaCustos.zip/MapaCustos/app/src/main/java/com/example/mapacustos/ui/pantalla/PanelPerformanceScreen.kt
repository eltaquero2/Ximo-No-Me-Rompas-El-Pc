package com.example.mapacustos.ui.pantalla

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.example.mapacustos.ui.datos.AppDatabase
import com.example.mapacustos.ui.datos.StreetDao
import com.example.mapacustos.ui.datos.StreetEntity
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polygon
import org.osmdroid.views.overlay.Polyline
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import androidx.compose.material.icons.filled.Settings
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.LocationServices


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PanelPerformanceScreen(navController: NavController) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dao = AppDatabase.getDatabase(context).streetDao()

    var expanded by remember { mutableStateOf(false) }
    var showMapDialog by remember { mutableStateOf(false) }
    var mapViewRef by remember { mutableStateOf<MapView?>(null) }

    var routeMode by remember { mutableStateOf(false) }
    var destinationText by remember { mutableStateOf("") }
    var currentRoute by remember { mutableStateOf<Polyline?>(null) }
    var ignoredLevels by remember { mutableStateOf(setOf<Int>()) }

    var expandedSuggestions by remember { mutableStateOf(false) }
    var streetSuggestions by remember { mutableStateOf(listOf<String>()) }
    val destinationFocusRequester = remember { FocusRequester() }

    var currentLocation by remember { mutableStateOf<GeoPoint?>(null) }
    var dangerOverlays by remember { mutableStateOf(mutableListOf<Polygon>()) }

    DisposableEffect(Unit) {
        org.osmdroid.config.Configuration.getInstance()
            .load(context, context.getSharedPreferences("osm_pref", Context.MODE_PRIVATE))
        onDispose { }
    }

    // Permisos de ubicación
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            if (ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                    if (location != null) {
                        currentLocation = GeoPoint(location.latitude, location.longitude)
                        mapViewRef?.controller?.setCenter(currentLocation)
                    }
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    Box(modifier = Modifier.fillMaxSize()) {

        /* ---------------- MAPA ---------------- */
        val defaultLocation = GeoPoint(39.1747, -0.4232) // Centro de Alzira

        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val mapView = MapView(ctx).apply {
                    setTileSource(TileSourceFactory.MAPNIK)
                    setMultiTouchControls(true)
                }

                mapView.controller.setZoom(15.0)

                // Si hay ubicación del GPS, centra ahí; si no, centra en Alzira
                mapView.controller.setCenter(currentLocation ?: defaultLocation)

                mapViewRef = mapView

                coroutineScope.launch {
                    dao.getAllStreets()
                        .filter { it.dangerLevel > 0 }
                        .forEach { addColoredArea(mapView, it, dangerOverlays) }
                }

                mapView
            },
            update = { map ->
                // Cada vez que currentLocation cambie, centra el mapa allí
                currentLocation?.let { map.controller.setCenter(it) }
            }
        )

        /* ---------------- PANEL RUTA ---------------- */
        AnimatedVisibility(
            visible = routeMode,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 90.dp)
        ) {
            Surface(
                shadowElevation = 12.dp,
                shape = MaterialTheme.shapes.large
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .width(330.dp)
                ) {
                    ExposedDropdownMenuBox(
                        expanded = expandedSuggestions,
                        onExpandedChange = { /* Controlado por input */ }
                    ) {
                        OutlinedTextField(
                            value = destinationText,
                            onValueChange = { input ->
                                destinationText = input
                                coroutineScope.launch {
                                    val all = dao.getAllStreets()
                                    streetSuggestions = all.map { it.name }
                                        .filter { it.contains(input, ignoreCase = true) }
                                        .take(5)
                                    expandedSuggestions = streetSuggestions.isNotEmpty()
                                }
                            },
                            label = { Text("Ir a calle...") },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .focusRequester(destinationFocusRequester),
                            singleLine = true
                        )

                        DropdownMenu(
                            expanded = expandedSuggestions,
                            onDismissRequest = { expandedSuggestions = false }
                        ) {
                            streetSuggestions.forEach { suggestion ->
                                DropdownMenuItem(
                                    text = { Text(suggestion) },
                                    onClick = {
                                        destinationText = suggestion
                                        expandedSuggestions = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Ignorar niveles:")

                    Row {
                        (1..3).forEach { level ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = ignoredLevels.contains(level),
                                    onCheckedChange = {
                                        ignoredLevels =
                                            if (it) ignoredLevels + level
                                            else ignoredLevels - level
                                    }
                                )
                                Text("N$level")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            coroutineScope.launch {
                                val startLocation = currentLocation
                                if (startLocation == null) return@launch // Esperando ubicación
                                val street = dao.getStreetByName(destinationText) ?: return@launch
                                val points = geoJsonToGeoPoints(street.geoJson)
                                if (points.isEmpty()) return@launch
                                val destination = points.first()
                                mapViewRef?.controller?.animateTo(destination)

                                drawRouteReal(
                                    dao,
                                    mapViewRef!!,
                                    startLocation,
                                    destination,
                                    ignoredLevels
                                ) { polyline ->
                                    currentRoute?.let { mapViewRef!!.overlays.remove(it) }
                                    currentRoute = polyline
                                    mapViewRef!!.overlays.add(polyline)
                                    mapViewRef!!.invalidate()
                                }
                            }
                        }
                    ) { Text("Ir") }
                }
            }
        }

        /* ---------------- BOTÓN MAPA ---------------- */
        Surface(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
                .size(60.dp),
            shadowElevation = 10.dp,
            shape = MaterialTheme.shapes.extraLarge,
            color = androidx.compose.ui.graphics.Color.White
        ) {
            IconButton(
                onClick = { routeMode = !routeMode },
                modifier = Modifier.fillMaxSize()
            ) {
                Icon(
                    imageVector = Icons.Default.Map,
                    contentDescription = "Ruta",
                    tint = androidx.compose.ui.graphics.Color.Black
                )
            }
        }

        /* ---------------- BOTÓN AJUSTES ---------------- */
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp)
        ) {
            Surface(
                shadowElevation = 10.dp,
                shape = MaterialTheme.shapes.extraLarge,
                color = androidx.compose.ui.graphics.Color.White
            ) {
                Box(
                    modifier = Modifier
                        .animateContentSize()
                        .width(if (expanded) 240.dp else 60.dp)
                        .then(
                            if (!expanded) Modifier.height(60.dp)
                            else Modifier.wrapContentHeight()
                        )
                ) {
                    if (!expanded) {
                        IconButton(
                            onClick = { expanded = true },
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Ajustes",
                                tint = androidx.compose.ui.graphics.Color.Black
                            )
                        }
                    } else {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                IconButton(onClick = { expanded = false }) {
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowRight,
                                        contentDescription = "Cerrar"
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            MenuButton("Ajustes de usuario") {
                                navController.navigate("userSettings")
                                expanded = false
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            MenuButton("Ajustes de sonido / color") {
                                navController.navigate("soundSettings")
                                expanded = false
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            MenuButton("Ajustes de mapa") {
                                showMapDialog = true
                                expanded = false
                            }
                        }
                    }
                }
            }
        }
    }

    /* ---------------- DIALOGO MAPA ---------------- */
    if (showMapDialog && mapViewRef != null) {
        MapSettingsDialog(
            context,
            dao,
            mapViewRef!!,
            onCancel = { showMapDialog = false },
            onApply = { streetEntity ->
                coroutineScope.launch {
                    dao.insertStreet(streetEntity)
                    clearDangerAreas(mapViewRef!!, dangerOverlays)
                    dao.getAllStreets()
                        .filter { it.dangerLevel > 0 }
                        .forEach { addColoredArea(mapViewRef!!, it, dangerOverlays) }
                }
                showMapDialog = false
            }
        )
    }
}

@Composable
fun MenuButton(text: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(55.dp),
        shape = MaterialTheme.shapes.medium,
        shadowElevation = 6.dp,
        tonalElevation = 0.dp
    ) {
        Box(
            contentAlignment = Alignment.CenterStart,
            modifier = Modifier.padding(start = 16.dp)
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.titleLarge
            )
        }
    }
}

// 🔹 CONVERTIR GEOJSON A LISTA DE GeoPoint
fun geoJsonToGeoPoints(geoJson: String): List<GeoPoint> {
    return try {
        val jsonObj = JSONObject(geoJson)
        val coordinates = jsonObj.getJSONArray("coordinates")
        List(coordinates.length()) {
            val pair = coordinates.getJSONArray(it)
            GeoPoint(pair.getDouble(1), pair.getDouble(0))
        }
    } catch (e: Exception) {
        emptyList()
    }
}

// 🔹 DIBUJAR AREA COLOREADA (HEATMAP, SEMI-TRANSPARENTE)
fun addColoredArea(
    mapView: MapView,
    street: StreetEntity,
    overlayList: MutableList<Polygon>
) {

    val originalPoints = geoJsonToGeoPoints(street.geoJson)
    if (originalPoints.size < 2) return

    val baseRadius = when (street.dangerLevel) {
        1 -> 18.0
        2 -> 18.0
        3 -> 18.0
        else -> return
    }

    val context = mapView.context
    val prefs = context.getSharedPreferences("color_cache", Context.MODE_PRIVATE)

    val hex = when (street.dangerLevel) {
        1 -> prefs.getString("color_l1", "#FFFF00")
        2 -> prefs.getString("color_l2", "#FFA500")
        3 -> prefs.getString("color_l3", "#FF0000")
        else -> null
    } ?: return

    val parsedColor = android.graphics.Color.parseColor(hex)

    var lastDrawnPoint: GeoPoint? = null
    val minDistanceMeters = baseRadius * 0.7

    for (i in 0 until originalPoints.size - 1) {

        val start = originalPoints[i]
        val end = originalPoints[i + 1]

        for (step in 0..22) {

            val fraction = step / 22.0
            val lat = start.latitude + (end.latitude - start.latitude) * fraction
            val lon = start.longitude + (end.longitude - start.longitude) * fraction
            val currentPoint = GeoPoint(lat, lon)

            if (lastDrawnPoint != null) {
                val distance = currentPoint.distanceToAsDouble(lastDrawnPoint)
                if (distance < minDistanceMeters) continue
            }

            lastDrawnPoint = currentPoint

            val circle = Polygon().apply {
                points = Polygon.pointsAsCircle(currentPoint, baseRadius)
                fillColor = android.graphics.Color.argb(
                    45,
                    android.graphics.Color.red(parsedColor),
                    android.graphics.Color.green(parsedColor),
                    android.graphics.Color.blue(parsedColor)
                )
                strokeWidth = 0f
                strokeColor = Color.TRANSPARENT
            }

            mapView.overlays.add(circle)
            overlayList.add(circle)
        }
    }

    mapView.invalidate()
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapSettingsDialog(
    context: Context,
    dao: StreetDao,
    mapView: MapView,
    onCancel: () -> Unit,
    onApply: (StreetEntity) -> Unit
) {
    val keyboardController = LocalSoftwareKeyboardController.current
    val coroutineScope = rememberCoroutineScope()
    var street by remember { mutableStateOf("") }
    var level by remember { mutableStateOf(0) }
    var violation by remember { mutableStateOf(false) }
    var violence by remember { mutableStateOf(false) }
    var tapToggle by remember { mutableStateOf(false) } // alterna comportamiento
    val focusRequester = remember { FocusRequester() }
    var expanded by remember { mutableStateOf(false) }
    var streetSuggestions by remember { mutableStateOf(listOf<String>()) }

    val streetFocusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        streetFocusRequester.requestFocus()
    }

    AlertDialog(
        onDismissRequest = onCancel,
        confirmButton = {},
        text = {
            Column {

                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { /* no hacemos nada aquí */ }
                ) {
                    var tapToggle by remember { mutableStateOf(false) } // alterna comportamiento
                    val focusRequester = remember { FocusRequester() }

                    OutlinedTextField(
                        value = street,
                        onValueChange = { input ->
                            street = input
                            // actualizar lista de sugerencias
                            coroutineScope.launch {
                                val allStreets = dao.getAllStreets()
                                streetSuggestions = allStreets
                                    .map { it.name }
                                    .filter { it.contains(input, ignoreCase = true) }
                                    .take(5)
                                expanded = streetSuggestions.isNotEmpty()
                            }
                        },
                        label = { Text("Calle") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onTap = {
                                        if (!tapToggle) {
                                            // click simple -> abre teclado
                                            focusRequester.requestFocus()
                                            keyboardController?.show() // fuerza mostrar teclado
                                        } else {
                                            // click siguiente -> abre lista
                                            expanded = true
                                        }
                                        tapToggle = !tapToggle // alterna para el siguiente click
                                    }
                                )
                            }
                            .focusRequester(focusRequester),
                        singleLine = true
                    )

                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        streetSuggestions.forEach { suggestion ->
                            DropdownMenuItem(
                                text = { Text(suggestion) },
                                onClick = {
                                    street = suggestion
                                    expanded = false
                                    coroutineScope.launch {
                                        val entity = dao.getStreetByName(suggestion)
                                        if (entity != null) {
                                            level = entity.dangerLevel
                                            violation = entity.includesViolation
                                            violence = entity.includesViolence
                                        }
                                    }
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Nivel: $level")
                Slider(
                    value = level.toFloat(),
                    onValueChange = {
                        level = it.toInt()
                        if (level == 3) {
                            violation = true
                            violence = true
                        }
                    },
                    valueRange = 0f..3f,
                    steps = 2
                )

                if (level == 0) {
                    Text("No hay criminalidad")
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = violation,
                            onCheckedChange = { if (level != 3) violation = it },
                            enabled = level != 3
                        )
                        Text("Incluye violación")
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = violence,
                            onCheckedChange = { if (level != 3) violence = it },
                            enabled = level != 3
                        )
                        Text("Incluye violencia")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(onClick = onCancel) { Text("Cancelar") }
                    Button(onClick = {
                        coroutineScope.launch {
                            val entity = dao.getStreetByName(street) ?: StreetEntity(
                                name = street,
                                geoJson = "{}"
                            )
                            val updatedEntity = entity.copy(
                                dangerLevel = level,
                                includesViolation = violation,
                                includesViolence = violence
                            )
                            onApply(updatedEntity)
                        }
                    }) { Text("Aplicar") }
                }
            }
        }
    )
}
suspend fun drawRouteReal(
    dao: StreetDao,
    mapView: MapView,
    start: GeoPoint,
    end: GeoPoint,
    allowedLevels: Set<Int>,
    onRouteReady: (Polyline) -> Unit
) {
    try {

        val allStreets = dao.getAllStreets()

        val startStreet = findStreetByLocation(start, allStreets)
        val endStreet = findStreetByLocation(end, allStreets)

        // 🔹 Intento 1: ruta directa
        val directRoute = requestRouteWithWaypoints(listOf(start, end))
        if (directRoute.isEmpty()) return

        val forbiddenStreet = getForbiddenStreet(
            directRoute,
            allStreets,
            allowedLevels,
            startStreet,
            endStreet
        )

        // ✅ Si la directa es válida, la usamos
        if (forbiddenStreet == null) {

            val polyline = Polyline().apply {
                outlinePaint.color = Color.BLUE
                outlinePaint.strokeWidth = 10f
                setPoints(directRoute)
            }

            onRouteReady(polyline)
            return
        }

        // 🔥 Si no es válida, probamos múltiples desvíos
        val candidates = findSafeDetourCandidates(forbiddenStreet)

        for (candidate in candidates) {

            val route = requestRouteWithWaypoints(
                listOf(start, candidate, end)
            )

            if (route.isEmpty()) continue

            val stillInvalid = getForbiddenStreet(
                route,
                allStreets,
                allowedLevels,
                startStreet,
                endStreet
            )

            if (stillInvalid == null) {

                val polyline = Polyline().apply {
                    outlinePaint.color = Color.BLUE
                    outlinePaint.strokeWidth = 10f
                    setPoints(route)
                }

                onRouteReady(polyline)
                return
            }
        }

        // ⚠ Si ningún desvío funciona, mostramos la directa
        val fallbackPolyline = Polyline().apply {
            outlinePaint.color = Color.BLUE
            outlinePaint.strokeWidth = 10f
            setPoints(directRoute)
        }

        onRouteReady(fallbackPolyline)

    } catch (e: Exception) {
        e.printStackTrace()
    }
}

suspend fun requestRoute(
    start: GeoPoint,
    end: GeoPoint
): List<GeoPoint> = withContext(Dispatchers.IO) {

    val client = OkHttpClient()

    val url =
        "https://router.project-osrm.org/route/v1/driving/" +
                "${start.longitude},${start.latitude};" +
                "${end.longitude},${end.latitude}" +
                "?overview=full&geometries=geojson"

    val request = Request.Builder().url(url).build()

    val response = client.newCall(request).execute()
    if (!response.isSuccessful) return@withContext emptyList()

    val body = response.body?.string() ?: return@withContext emptyList()

    val json = JSONObject(body)
    val routes = json.getJSONArray("routes")
    if (routes.length() == 0) return@withContext emptyList()

    val coordinates = routes
        .getJSONObject(0)
        .getJSONObject("geometry")
        .getJSONArray("coordinates")

    val points = mutableListOf<GeoPoint>()

    for (i in 0 until coordinates.length()) {
        val pair = coordinates.getJSONArray(i)
        points.add(GeoPoint(pair.getDouble(1), pair.getDouble(0)))
    }

    points
}

fun routeContainsForbiddenStreet(
    routePoints: List<GeoPoint>,
    streets: List<StreetEntity>,
    allowedLevels: Set<Int>,
    startStreet: StreetEntity?,
    endStreet: StreetEntity?
): Boolean {

    for (street in streets) {

        // 🔹 Si es calle inicio o destino → ignoramos restricciones
        if (street == startStreet || street == endStreet) continue

        // 🔹 Si el nivel NO está permitido → es prohibido
        if (street.dangerLevel > 0 && street.dangerLevel !in allowedLevels) {

            val streetPoints = geoJsonToGeoPoints(street.geoJson)

            for (routePoint in routePoints) {
                for (streetPoint in streetPoints) {
                    if (routePoint.distanceToAsDouble(streetPoint) < 15.0) {
                        return true
                    }
                }
            }
        }
    }

    return false
}

fun findStreetByLocation(
    point: GeoPoint,
    streets: List<StreetEntity>
): StreetEntity? {

    for (street in streets) {

        val points = geoJsonToGeoPoints(street.geoJson)

        for (p in points) {
            if (point.distanceToAsDouble(p) < 20.0) {
                return street
            }
        }
    }

    return null
}

fun findSafeDetourCandidates(
    forbiddenStreet: StreetEntity
): List<GeoPoint> {

    val points = geoJsonToGeoPoints(forbiddenStreet.geoJson)
    if (points.isEmpty()) return emptyList()

    val middle = points[points.size / 2]

    val offsets = listOf(
        0.0004 to 0.0,
        -0.0004 to 0.0,
        0.0 to 0.0004,
        0.0 to -0.0004,
        0.0005 to 0.0005,
        -0.0005 to -0.0005
    )

    return offsets.map {
        GeoPoint(
            middle.latitude + it.first,
            middle.longitude + it.second
        )
    }
}

fun getForbiddenStreet(
    routePoints: List<GeoPoint>,
    streets: List<StreetEntity>,
    allowedLevels: Set<Int>,
    startStreet: StreetEntity?,
    endStreet: StreetEntity?
): StreetEntity? {

    for (street in streets) {

        if (street == startStreet || street == endStreet) continue

        if (street.dangerLevel > 0 && street.dangerLevel !in allowedLevels) {

            val streetPoints = geoJsonToGeoPoints(street.geoJson)

            for (routePoint in routePoints) {
                for (streetPoint in streetPoints) {
                    if (routePoint.distanceToAsDouble(streetPoint) < 15.0) {
                        return street
                    }
                }
            }
        }
    }

    return null
}

suspend fun requestRouteWithWaypoints(
    waypoints: List<GeoPoint>
): List<GeoPoint> = withContext(Dispatchers.IO) {

    if (waypoints.size < 2) return@withContext emptyList()

    val client = OkHttpClient()

    // Construimos la parte de coordenadas dinámicamente
    val coordinatesString = waypoints.joinToString(";") {
        "${it.longitude},${it.latitude}"
    }

    val url =
        "https://router.project-osrm.org/route/v1/driving/" +
                coordinatesString +
                "?overview=full&geometries=geojson"

    val request = Request.Builder().url(url).build()

    val response = client.newCall(request).execute()
    if (!response.isSuccessful) return@withContext emptyList()

    val body = response.body?.string() ?: return@withContext emptyList()

    val json = JSONObject(body)
    val routes = json.getJSONArray("routes")
    if (routes.length() == 0) return@withContext emptyList()

    val coordinates = routes
        .getJSONObject(0)
        .getJSONObject("geometry")
        .getJSONArray("coordinates")

    val points = mutableListOf<GeoPoint>()

    for (i in 0 until coordinates.length()) {
        val pair = coordinates.getJSONArray(i)
        points.add(GeoPoint(pair.getDouble(1), pair.getDouble(0)))
    }

    points
}

fun clearDangerAreas(
    mapView: MapView,
    overlays: MutableList<Polygon>
) {
    overlays.forEach {
        mapView.overlays.remove(it)
    }
    overlays.clear()
    mapView.invalidate()
}