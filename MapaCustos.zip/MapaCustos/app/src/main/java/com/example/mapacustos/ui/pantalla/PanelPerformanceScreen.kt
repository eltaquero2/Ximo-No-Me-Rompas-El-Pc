package com.example.mapacustos.ui.pantalla

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.example.mapacustos.ui.datos.AppDatabase
import com.example.mapacustos.ui.datos.StreetDao
import com.example.mapacustos.ui.datos.StreetEntity
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polygon
import org.osmdroid.views.overlay.Polyline
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import androidx.compose.material.icons.filled.Settings
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.LocationServices
import android.graphics.Color as AndroidColor
import coil.ImageLoader
import coil.decode.GifDecoder
import coil.request.ImageRequest
import coil.compose.rememberAsyncImagePainter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PanelPerformanceScreen(navController: NavController) {

    // Contexto de Android necesario para acceder a recursos, DB, permisos, etc.
    val context = LocalContext.current

    // Scope para lanzar corutinas desde Compose
    val coroutineScope = rememberCoroutineScope()

    // DAO de la base de datos (Room)
    val dao = AppDatabase.getDatabase(context).streetDao()

    // Controla si se muestra el GIF de carga mientras se calcula la ruta
    var isLoadingRoute by remember { mutableStateOf(false) }

    // Control del panel de ajustes
    var expanded by remember { mutableStateOf(false)}

    // Controla si se muestra el diálogo de ajustes del mapa
    var showMapDialog by remember { mutableStateOf(false)}

    // Referencia al MapView de osmdroid
    var mapViewRef by remember { mutableStateOf<MapView?>(null)}

    // Activa o desactiva el modo ruta
    var routeMode by remember { mutableStateOf(false)}

    // Texto del destino escrito por el usuario
    var destinationText by remember { mutableStateOf("")}

    // Ruta actual dibujada en el mapa
    var currentRoute by remember { mutableStateOf<Polyline?>(null)}

    // Niveles de peligro que el usuario ha decidido ignorar
    var ignoredLevels by remember { mutableStateOf(setOf<Int>())}

    // Control del dropdown de sugerencias
    var expandedSuggestions by remember { mutableStateOf(false)}

    // Lista de calles sugeridas
    var streetSuggestions by remember { mutableStateOf(listOf<String>())}

    // Focus para el campo de destino
    val destinationFocusRequester = remember { FocusRequester() }

    // Ubicación actual del usuario
    var currentLocation by remember { mutableStateOf<GeoPoint?>(null)}

    // Lista de overlays de zonas peligrosas (heatmap)
    var dangerOverlays by remember { mutableStateOf(mutableListOf<Polygon>())}

    // ImageLoader necesario para reproducir GIFs con Coil
    val imageLoader = ImageLoader.Builder(context)
        .components {
            add(GifDecoder.Factory())
        }
        .build()

    /*
    Inicialización de configuración de osmdroid
    Se carga la configuración desde SharedPreferences
     */
    DisposableEffect(Unit) {
        org.osmdroid.config.Configuration.getInstance()
            .load(context, context.getSharedPreferences("osm_pref", Context.MODE_PRIVATE))
        onDispose { }
    }

    /*
    -------------------------------------------------
    PERMISOS DE UBICACIÓN
    -------------------------------------------------
     */

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->

        if (granted) {

            // Cliente de ubicación de Google
            val fusedLocationClient =
                LocationServices.getFusedLocationProviderClient(context)

            if (ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {

                // Obtener última ubicación conocida
                fusedLocationClient.lastLocation.addOnSuccessListener { location ->

                    if (location != null) {

                        // Guardamos la ubicación actual
                        currentLocation = GeoPoint(location.latitude, location.longitude)

                        // Centramos el mapa en la posición del usuario
                        mapViewRef?.controller?.setCenter(currentLocation)
                    }
                }
            }
        }
    }

    // Lanzamos la petición de permisos al iniciar la pantalla
    LaunchedEffect(Unit) {
        locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    /*
    -------------------------------------------------
    CONTENEDOR PRINCIPAL
    -------------------------------------------------
     */

    Box(modifier = Modifier.fillMaxSize()) {

        /*
        -------------------------------------------------
        MAPA (OSMDROID)
        -------------------------------------------------
         */

        // Ubicación por defecto (centro de Alzira)
        val defaultLocation = GeoPoint(39.1747, -0.4232)

        AndroidView(
            modifier = Modifier.fillMaxSize(),

            factory = { ctx ->

                // Crear mapa
                val mapView = MapView(ctx).apply {
                    setTileSource(TileSourceFactory.MAPNIK)
                    setMultiTouchControls(true)
                }

                // Zoom inicial
                mapView.controller.setZoom(15.0)

                // Centrar mapa
                mapView.controller.setCenter(currentLocation ?: defaultLocation)

                // Guardamos referencia
                mapViewRef = mapView

                /*
                Cargar zonas peligrosas desde la base de datos
                 */
                coroutineScope.launch {

                    dao.getAllStreets()
                        .filter { it.dangerLevel > 0 }
                        .forEach {
                            addColoredArea(mapView, it, dangerOverlays)
                        }
                }

                mapView
            },

            update = { map ->

                // Si cambia la ubicación actual se centra el mapa
                currentLocation?.let {
                    map.controller.setCenter(it)
                }
            }
        )

        /*
        -------------------------------------------------
        GIF DE CARGA DE RUTA
        -------------------------------------------------
         */

        if (isLoadingRoute) {

            val painter = rememberAsyncImagePainter(
                model = ImageRequest.Builder(context)
                    .data("file:///android_asset/loading.gif")
                    .build(),
                imageLoader = imageLoader
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(androidx.compose.ui.graphics.Color(0x88000000)),
                contentAlignment = Alignment.Center
            ) {

                // Imagen GIF animada
                Image(
                    painter = painter,
                    contentDescription = "Cargando ruta",
                    modifier = Modifier.size(120.dp)
                )
            }
        }

        /*
        -------------------------------------------------
        PANEL DE RUTA
        -------------------------------------------------
         */

        AnimatedVisibility(
            visible = routeMode,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 90.dp)
        ) {

            Surface(
                shadowElevation = 12.dp,
                shape = MaterialTheme.shapes.large
            ) {

                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .width(330.dp)
                ) {

                    /*
                    BUSCADOR DE CALLES
                     */

                    ExposedDropdownMenuBox(
                        expanded = expandedSuggestions,
                        onExpandedChange = {}
                    ) {

                        OutlinedTextField(
                            value = destinationText,

                            // Cuando el usuario escribe
                            onValueChange = { input ->

                                destinationText = input

                                coroutineScope.launch {

                                    // Buscar coincidencias en la base de datos
                                    val all = dao.getAllStreets()

                                    streetSuggestions =
                                        all.map { it.name }
                                            .filter {
                                                it.contains(input, ignoreCase = true)
                                            }
                                            .take(5)

                                    expandedSuggestions =
                                        streetSuggestions.isNotEmpty()
                                }
                            },

                            label = { Text("Ir a calle...") },

                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .focusRequester(destinationFocusRequester),

                            singleLine = true
                        )

                        /*
                        LISTA DE SUGERENCIAS
                         */

                        DropdownMenu(
                            expanded = expandedSuggestions,
                            onDismissRequest = { expandedSuggestions = false }
                        ) {

                            streetSuggestions.forEach { suggestion ->

                                DropdownMenuItem(
                                    text = { Text(suggestion) },

                                    onClick = {
                                        destinationText = suggestion
                                        expandedSuggestions = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    /*
                    CHECKBOX PARA IGNORAR NIVELES
                     */

                    Text("Ignorar niveles:")

                    Row {

                        (1..3).forEach { level ->

                            Row(verticalAlignment = Alignment.CenterVertically) {

                                Checkbox(
                                    checked = ignoredLevels.contains(level),

                                    onCheckedChange = {

                                        ignoredLevels =
                                            if (it) ignoredLevels + level
                                            else ignoredLevels - level
                                    }
                                )

                                Text("N$level")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    /*
                    BOTÓN PARA CALCULAR RUTA
                     */

                    Button(
                        modifier = Modifier.fillMaxWidth(),

                        onClick = {

                            coroutineScope.launch {

                                val startLocation =
                                    currentLocation ?: return@launch

                                val street =
                                    dao.getStreetByName(destinationText)
                                        ?: return@launch

                                val points =
                                    geoJsonToGeoPoints(street.geoJson)

                                if (points.isEmpty()) return@launch

                                val destination = points.first()

                                // Mover mapa al destino
                                mapViewRef?.controller?.animateTo(destination)

                                // Mostrar GIF
                                isLoadingRoute = true

                                // Calcular ruta evitando zonas peligrosas
                                drawRouteReal(
                                    dao,
                                    mapViewRef!!,
                                    startLocation,
                                    destination,
                                    ignoredLevels
                                ) { polyline ->

                                    // Borrar ruta anterior
                                    currentRoute?.let {
                                        mapViewRef!!.overlays.remove(it)
                                    }

                                    // Guardar nueva ruta
                                    currentRoute = polyline

                                    // Añadir al mapa
                                    mapViewRef!!.overlays.add(polyline)
                                    mapViewRef!!.invalidate()
                                }

                                // Ocultar GIF
                                isLoadingRoute = false
                            }
                        }
                    ) { Text("Ir") }
                }
            }
        }

        /*
        -------------------------------------------------
        BOTÓN MODO RUTA
        -------------------------------------------------
         */

        Surface(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
                .size(60.dp),

            shadowElevation = 10.dp,
            shape = MaterialTheme.shapes.extraLarge,
            color = androidx.compose.ui.graphics.Color.White
        ) {

            IconButton(
                onClick = { routeMode = !routeMode },
                modifier = Modifier.fillMaxSize()
            ) {

                Icon(
                    imageVector = Icons.Default.Map,
                    contentDescription = "Ruta",
                    tint = androidx.compose.ui.graphics.Color.Black
                )
            }
        }

        /*
        -------------------------------------------------
        BOTÓN AJUSTES
        -------------------------------------------------
         */

        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp)
        ) {

            Surface(
                shadowElevation = 10.dp,
                shape = MaterialTheme.shapes.extraLarge,
                color = androidx.compose.ui.graphics.Color.White
            ) {

                Box(
                    modifier = Modifier
                        .animateContentSize()
                        .width(if (expanded) 240.dp else 60.dp)
                        .then(
                            if (!expanded) Modifier.height(60.dp)
                            else Modifier.wrapContentHeight()
                        )
                ) {

                    if (!expanded) {

                        IconButton(
                            onClick = { expanded = true },
                            modifier = Modifier.fillMaxSize()
                        ) {

                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Ajustes",
                                tint = androidx.compose.ui.graphics.Color.Black
                            )
                        }

                    } else {

                        Column(modifier = Modifier.padding(16.dp)) {

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {

                                IconButton(onClick = { expanded = false }) {

                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowRight,
                                        contentDescription = "Cerrar"
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            MenuButton("Ajustes de usuario") {
                                navController.navigate("userSettings")
                                expanded = false
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            MenuButton("Ajustes de sonido / color") {
                                navController.navigate("soundSettings")
                                expanded = false
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            MenuButton("Ajustes de mapa") {
                                showMapDialog = true
                                expanded = false
                            }
                        }
                    }
                }
            }
        }
    }

    /*
    -------------------------------------------------
    DIÁLOGO AJUSTES DE MAPA
    -------------------------------------------------
     */

    if (showMapDialog && mapViewRef != null) {

        MapSettingsDialog(
            context,
            dao,
            mapViewRef!!,

            onCancel = {
                showMapDialog = false
            },

            onApply = { streetEntity ->

                coroutineScope.launch {

                    // Guardar cambios en DB
                    dao.insertStreet(streetEntity)

                    // Borrar heatmap anterior
                    clearDangerAreas(mapViewRef!!, dangerOverlays)

                    // Redibujar heatmap
                    dao.getAllStreets()
                        .filter { it.dangerLevel > 0 }
                        .forEach {
                            addColoredArea(mapViewRef!!, it, dangerOverlays)
                        }
                }

                showMapDialog = false
            }
        )
    }
}

@Composable
fun MenuButton(text: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(55.dp),
        shape = MaterialTheme.shapes.medium,
        shadowElevation = 6.dp,
        tonalElevation = 0.dp
    ) {
        Box(
            contentAlignment = Alignment.CenterStart,
            modifier = Modifier.padding(start = 16.dp)
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.titleLarge
            )
        }
    }
}

// 🔹 CONVERTIR GEOJSON A LISTA DE GeoPoint
fun geoJsonToGeoPoints(geoJson: String): List<GeoPoint> {
    return try {
        val jsonObj = JSONObject(geoJson)
        val coordinates = jsonObj.getJSONArray("coordinates")
        List(coordinates.length()) {
            val pair = coordinates.getJSONArray(it)
            GeoPoint(pair.getDouble(1), pair.getDouble(0))
        }
    } catch (e: Exception) {
        emptyList()
    }
}

// 🔹 DIBUJAR AREA COLOREADA (HEATMAP, SEMI-TRANSPARENTE)
fun addColoredArea(
    mapView: MapView,                 // mapa de osmdroid donde se dibuja
    street: StreetEntity,             // calle con su información (geoJson + nivel de peligro)
    overlayList: MutableList<Polygon> // lista donde guardamos los overlays creados
) {

    // Convertimos el GeoJSON de la calle a una lista de GeoPoints
    val originalPoints = geoJsonToGeoPoints(street.geoJson)

    // Si la calle tiene menos de 2 puntos no se puede dibujar una línea
    if (originalPoints.size < 2) return

    // Radio del círculo que se dibuja alrededor de cada punto
    val baseRadius = 18.0

    // Obtenemos el contexto del mapa
    val context = mapView.context

    // Accedemos a las preferencias donde guardas los colores configurados
    val prefs = context.getSharedPreferences("color_cache", Context.MODE_PRIVATE)

    // Seleccionamos el color según el nivel de peligro de la calle
    val hex = when (street.dangerLevel) {

        // Nivel 1 → amarillo
        1 -> prefs.getString("color_l1", "#FFFF00")

        // Nivel 2 → naranja
        2 -> prefs.getString("color_l2", "#FFA500")

        // Nivel 3 → rojo
        3 -> prefs.getString("color_l3", "#FF0000")

        // Nivel 0 u otro → no dibujar
        else -> null
    } ?: return

    // Convertimos el color HEX a formato Android
    val parsedColor = AndroidColor.parseColor(hex)

    // Último punto donde se dibujó un círculo (para evitar superposición)
    var lastDrawnPoint: GeoPoint? = null

    // Distancia mínima entre círculos
    val minDistanceMeters = baseRadius * 0.7

    // Recorremos todos los segmentos de la calle
    // (cada par de puntos consecutivos)
    for (i in 0 until originalPoints.size - 1) {

        val start = originalPoints[i]      // punto inicial del segmento
        val end = originalPoints[i + 1]    // punto final del segmento

        // Dividimos el segmento en 22 pasos intermedios
        for (step in 0..22) {

            // Calculamos la fracción del recorrido (0.0 → 1.0)
            val fraction = step / 22.0

            // Interpolamos la posición entre start y end
            val lat = start.latitude + (end.latitude - start.latitude) * fraction
            val lon = start.longitude + (end.longitude - start.longitude) * fraction

            val currentPoint = GeoPoint(lat, lon)

            // Si ya dibujamos un círculo antes
            if (lastDrawnPoint != null) {

                // Calculamos la distancia al último punto dibujado
                val distance = currentPoint.distanceToAsDouble(lastDrawnPoint)

                // Si está demasiado cerca, lo saltamos
                if (distance < minDistanceMeters) continue
            }

            // Guardamos este punto como el último dibujado
            lastDrawnPoint = currentPoint

            // Creamos un polígono circular (un círculo)
            val circle = Polygon().apply {

                // Generamos los puntos que forman el círculo
                points = Polygon.pointsAsCircle(currentPoint, baseRadius)

                // Color de relleno semi-transparente (heatmap)
                fillColor = AndroidColor.argb(
                    45,                             // transparencia (0-255)
                    AndroidColor.red(parsedColor),   // rojo
                    AndroidColor.green(parsedColor), // verde
                    AndroidColor.blue(parsedColor)   // azul
                )

                // Sin borde
                strokeWidth = 0f
                strokeColor = AndroidColor.TRANSPARENT
            }

            // Añadimos el círculo al mapa
            mapView.overlays.add(circle)

            // También lo guardamos en la lista de overlays
            overlayList.add(circle)
        }
    }

    // Refrescamos el mapa para que se vean los cambios
    mapView.invalidate()
}


// Permite usar APIs experimentales de Material3
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapSettingsDialog(
    context: Context,
    dao: StreetDao,          // DAO de la base de datos de calles
    mapView: MapView,        // referencia al mapa (osmdroid)
    onCancel: () -> Unit,    // función que se ejecuta al cancelar
    onApply: (StreetEntity) -> Unit // función que se ejecuta al aplicar cambios
) {

    // Controlador del teclado virtual
    val keyboardController = LocalSoftwareKeyboardController.current

    // Scope para lanzar corrutinas desde Compose
    val coroutineScope = rememberCoroutineScope()

    // Estado del nombre de la calle escrito por el usuario
    var street by remember { mutableStateOf("") }

    // Nivel de criminalidad de la calle (0-3)
    var level by remember { mutableStateOf(0) }

    // Checkbox de si incluye violación
    var violation by remember { mutableStateOf(false) }

    // Checkbox de si incluye violencia
    var violence by remember { mutableStateOf(false) }

    // Alterna comportamiento del tap (abrir teclado / abrir lista)
    var tapToggle by remember { mutableStateOf(false) }

    // Permite pedir foco al TextField
    val focusRequester = remember { FocusRequester() }

    // Controla si el menú de sugerencias está abierto
    var expanded by remember { mutableStateOf(false) }

    // Lista de sugerencias de calles
    var streetSuggestions by remember { mutableStateOf(listOf<String>()) }

    // FocusRequester específico para el campo de calle
    val streetFocusRequester = remember { FocusRequester() }

    // Cuando el diálogo aparece, el campo de calle recibe foco automáticamente
    LaunchedEffect(Unit) {
        streetFocusRequester.requestFocus()
    }

    // Diálogo de Material3
    AlertDialog(
        onDismissRequest = onCancel, // cerrar al tocar fuera
        confirmButton = {}, // no usamos botón confirm aquí
        text = {

            // Contenedor vertical
            Column {

                // Componente para TextField con menú desplegable
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { /* no hacemos nada aquí */ }
                ) {

                    // Toggle local para alternar comportamiento de click
                    var tapToggle by remember { mutableStateOf(false) }

                    // FocusRequester local
                    val focusRequester = remember { FocusRequester() }

                    // Campo de texto para escribir la calle
                    OutlinedTextField(
                        value = street,
                        onValueChange = { input ->

                            // Actualizamos texto
                            street = input

                            // Buscamos sugerencias en la base de datos
                            coroutineScope.launch {

                                // obtenemos todas las calles
                                val allStreets = dao.getAllStreets()

                                // filtramos las que coinciden con lo escrito
                                streetSuggestions = allStreets
                                    .map { it.name }
                                    .filter { it.contains(input, ignoreCase = true) }
                                    .take(5) // máximo 5 sugerencias

                                // mostramos menú si hay sugerencias
                                expanded = streetSuggestions.isNotEmpty()
                            }
                        },
                        label = { Text("Calle") },

                        modifier = Modifier
                            .fillMaxWidth()

                            // Detecta taps personalizados
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onTap = {

                                        if (!tapToggle) {
                                            // Primer click -> abrir teclado
                                            focusRequester.requestFocus()
                                            keyboardController?.show()
                                        } else {
                                            // Segundo click -> abrir lista
                                            expanded = true
                                        }

                                        // alterna comportamiento para el siguiente tap
                                        tapToggle = !tapToggle
                                    }
                                )
                            }

                            // asigna el focusRequester al campo
                            .focusRequester(focusRequester),

                        singleLine = true
                    )

                    // Menú desplegable de sugerencias
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {

                        // Recorremos las sugerencias
                        streetSuggestions.forEach { suggestion ->

                            DropdownMenuItem(
                                text = { Text(suggestion) },

                                onClick = {

                                    // Seleccionamos la sugerencia
                                    street = suggestion

                                    // cerramos menú
                                    expanded = false

                                    coroutineScope.launch {

                                        // buscamos la calle en la base de datos
                                        val entity = dao.getStreetByName(suggestion)

                                        // si existe cargamos sus datos
                                        if (entity != null) {
                                            level = entity.dangerLevel
                                            violation = entity.includesViolation
                                            violence = entity.includesViolence
                                        }
                                    }
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Texto que muestra el nivel actual
                Text("Nivel: $level")

                // Slider para elegir nivel de criminalidad
                Slider(
                    value = level.toFloat(),
                    onValueChange = {

                        // actualizamos nivel
                        level = it.toInt()

                        // si es nivel máximo activamos todo
                        if (level == 3) {
                            violation = true
                            violence = true
                        }
                    },
                    valueRange = 0f..3f, // rango de valores
                    steps = 2            // 0,1,2,3
                )

                // Si nivel 0 no hay criminalidad
                if (level == 0) {
                    Text("No hay criminalidad")
                } else {

                    // Checkbox de violación
                    Row(verticalAlignment = Alignment.CenterVertically) {

                        Checkbox(
                            checked = violation,

                            onCheckedChange = {
                                if (level != 3) violation = it
                            },

                            enabled = level != 3
                        )

                        Text("Incluye violación")
                    }

                    // Checkbox de violencia
                    Row(verticalAlignment = Alignment.CenterVertically) {

                        Checkbox(
                            checked = violence,

                            onCheckedChange = {
                                if (level != 3) violence = it
                            },

                            enabled = level != 3
                        )

                        Text("Incluye violencia")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Botones inferiores
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {

                    // Botón cancelar
                    Button(onClick = onCancel) {
                        Text("Cancelar")
                    }

                    // Botón aplicar cambios
                    Button(onClick = {

                        coroutineScope.launch {

                            // buscamos la calle existente
                            val entity = dao.getStreetByName(street)

                            // si no existe creamos una nueva
                                ?: StreetEntity(
                                    name = street,
                                    geoJson = "{}"
                                )

                            // copiamos entidad con los nuevos valores
                            val updatedEntity = entity.copy(
                                dangerLevel = level,
                                includesViolation = violation,
                                includesViolence = violence
                            )

                            // devolvemos resultado
                            onApply(updatedEntity)
                        }

                    }) {
                        Text("Aplicar")
                    }
                }
            }
        }
    )
}


/**
 * Calcula una ruta entre dos puntos evitando calles peligrosas si es posible.
 *
 * Funcionamiento:
 * 1. Obtiene todas las calles guardadas en la base de datos.
 * 2. Genera varias rutas posibles (una directa y varias alternativas).
 * 3. Analiza cada ruta y calcula una "puntuación de peligro".
 * 4. La ruta con menor peligro es seleccionada.
 *
 * Reglas:
 * - Las calles con niveles marcados en ignoredLevels se pueden usar.
 * - Si no existe una ruta completamente segura, se usa la que tenga
 *   la menor cantidad de puntos peligrosos.
 *
 * @param dao acceso a la base de datos de calles
 * @param mapView mapa donde se dibujará la ruta
 * @param start ubicación inicial
 * @param end ubicación destino
 * @param ignoredLevels niveles de peligro permitidos por el usuario
 * @param onRouteReady callback que devuelve la Polyline lista para dibujar
 */
suspend fun drawRouteReal(
    dao: StreetDao,
    mapView: MapView,
    start: GeoPoint,
    end: GeoPoint,
    ignoredLevels: Set<Int>,
    onRouteReady: (Polyline) -> Unit
) {

    try {

        // Obtener todas las calles almacenadas en la base de datos
        val allStreets = dao.getAllStreets()

        // Lista donde guardaremos todas las rutas candidatas
        val routes = mutableListOf<List<GeoPoint>>()


        /*---------------------------------------------------------
        1️⃣ RUTA DIRECTA
        ---------------------------------------------------------*/

        // Intentamos primero la ruta más corta entre inicio y destino
        val direct = requestRouteWithWaypoints(listOf(start, end))

        // Si la API devuelve una ruta válida la añadimos a la lista
        if (direct.isNotEmpty()) routes.add(direct)


        /*---------------------------------------------------------
        2️⃣ GENERAR RUTAS ALTERNATIVAS
        ---------------------------------------------------------*/

        // Offsets que desplazan el punto medio para forzar rutas diferentes
        val offsets = listOf(
            Pair(0.0015, 0.0),
            Pair(0.0, 0.0015),
            Pair(-0.0015, 0.0)
        )

        for (offset in offsets) {

            // Punto medio desplazado entre inicio y destino
            val mid = GeoPoint(
                (start.latitude + end.latitude) / 2 + offset.first,
                (start.longitude + end.longitude) / 2 + offset.second
            )

            // Pedimos una ruta pasando por ese punto intermedio
            val route = requestRouteWithWaypoints(
                listOf(start, mid, end)
            )

            // Si la ruta es válida la añadimos
            if (route.isNotEmpty())
                routes.add(route)
        }

        // Si ninguna ruta fue generada salimos
        if (routes.isEmpty()) return


        /*---------------------------------------------------------
        3️⃣ EVALUAR CADA RUTA
        ---------------------------------------------------------*/

        var bestRoute = routes.first()   // mejor ruta encontrada
        var bestScore = Int.MAX_VALUE    // puntuación de peligro mínima

        for (route in routes) {

            var score = 0

            // Analizamos puntos de la ruta cada 8 pasos para ahorrar CPU
            for (i in route.indices step 8) {

                val point = route[i]

                // Detectamos si el punto está dentro de una calle peligrosa
                val street = findStreetByLocation(point, allStreets)

                if (street != null) {

                    // Si el nivel NO está permitido sumamos penalización
                    if (street.dangerLevel !in ignoredLevels) {
                        score += street.dangerLevel
                    }
                }
            }

            // Guardamos la ruta con menor puntuación de peligro
            if (score < bestScore) {
                bestScore = score
                bestRoute = route
            }
        }


        /*---------------------------------------------------------
        4️⃣ DIBUJAR LA MEJOR RUTA
        ---------------------------------------------------------*/

        val polyline = Polyline().apply {

            // Color azul estilo Google Maps
            outlinePaint.color = AndroidColor.BLUE

            // Grosor de línea
            outlinePaint.strokeWidth = 10f

            // Puntos que forman la ruta
            setPoints(bestRoute)
        }

        // Devolvemos la ruta lista para añadir al mapa
        onRouteReady(polyline)

    } catch (e: Exception) {

        // En caso de error se imprime en Logcat
        e.printStackTrace()
    }
}

fun findStreetByLocation(
    point: GeoPoint,
    streets: List<StreetEntity>
): StreetEntity? {

    for (street in streets) {

        val points = geoJsonToGeoPoints(street.geoJson)

        for (p in points) {
            if (point.distanceToAsDouble(p) < 20.0) {
                return street
            }
        }
    }

    return null
}


// Función suspend para pedir una ruta al servidor OSRM pasando varios puntos (waypoints)
// Devuelve una lista de GeoPoint que representan la línea de la ruta
suspend fun requestRouteWithWaypoints(
    waypoints: List<GeoPoint>
): List<GeoPoint> = withContext(Dispatchers.IO) {

    // Si hay menos de 2 puntos no se puede calcular una ruta
    // (se necesita al menos origen y destino)
    if (waypoints.size < 2) return@withContext emptyList()

    // Cliente HTTP que se usará para hacer la petición a la API de rutas
    val client = OkHttpClient()

    // Construimos el string de coordenadas que pide OSRM
    // Formato: longitud,latitud;longitud,latitud;...
    val coordinatesString = waypoints.joinToString(";") {
        "${it.longitude},${it.latitude}"
    }

    // Construcción de la URL de la API de OSRM
    // router.project-osrm.org es un servidor público de rutas
    val url =
        "https://router.project-osrm.org/route/v1/driving/" +
                coordinatesString +
                "?overview=full&geometries=geojson"

    // Creamos la petición HTTP
    val request = Request.Builder().url(url).build()

    // Ejecutamos la petición de forma síncrona
    val response = client.newCall(request).execute()

    // Si la respuesta no fue correcta (ej: error 404 o 500)
    // devolvemos una lista vacía
    if (!response.isSuccessful) return@withContext emptyList()

    // Convertimos el cuerpo de la respuesta a texto
    val body = response.body?.string() ?: return@withContext emptyList()

    // Parseamos el JSON recibido
    val json = JSONObject(body)

    // Obtenemos la lista de rutas posibles
    val routes = json.getJSONArray("routes")

    // Si no hay rutas disponibles devolvemos lista vacía
    if (routes.length() == 0) return@withContext emptyList()

    // Dentro de la primera ruta obtenemos la geometría (la línea de la ruta)
    val coordinates = routes
        .getJSONObject(0)
        .getJSONObject("geometry")
        .getJSONArray("coordinates")

    // Lista donde guardaremos los puntos convertidos a GeoPoint
    val points = mutableListOf<GeoPoint>()

    // Recorremos todas las coordenadas de la ruta
    for (i in 0 until coordinates.length()) {

        // Cada punto viene como [longitud, latitud]
        val pair = coordinates.getJSONArray(i)

        // Convertimos el punto a GeoPoint (latitud, longitud)
        points.add(GeoPoint(pair.getDouble(1), pair.getDouble(0)))
    }

    // Devolvemos la lista de puntos que forman la ruta
    points
}
fun clearDangerAreas(
    mapView: MapView,
    overlays: MutableList<Polygon>
) {
    overlays.forEach {
        mapView.overlays.remove(it)
    }
    overlays.clear()
    mapView.invalidate()
}