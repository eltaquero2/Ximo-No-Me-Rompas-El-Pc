package com.example.mapacustos.ui.pantalla

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.mapacustos.ui.datos.AppDatabase
import com.example.mapacustos.ui.datos.UserEntity
import kotlinx.coroutines.launch
import android.app.DatePickerDialog
import androidx.compose.foundation.clickable
import java.util.Calendar
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import com.example.mapacustos.ui.datos.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserSettingsScreen(navController: NavController) {

    val context = LocalContext.current
    val dao = AppDatabase.getDatabase(context).userDao()
    val coroutineScope = rememberCoroutineScope()

    val prefs = context.getSharedPreferences("session", Context.MODE_PRIVATE)
    val email = prefs.getString("current_user", null)

    var user by remember { mutableStateOf<UserEntity?>(null) }

    var password by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("Otros") }

    val calendar = Calendar.getInstance()

    LaunchedEffect(Unit) {
        if (email != null) {
            val loadedUser = dao.getUserByEmail(email)
            user = loadedUser
            loadedUser?.let {
                password = it.password
                birthDate = it.birthDate
                gender = it.gender
            }
        }
    }

    if (user == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No hay usuario activo")
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        Text("Ajustes de usuario", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = user!!.email,
            onValueChange = {},
            label = { Text("Gmail") },
            readOnly = true,
            enabled = false, // 🔥 lo deja visualmente desactivado
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Contraseña") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = birthDate,
            onValueChange = {},
            readOnly = true,
            label = { Text("Birth Date") },
            modifier = Modifier
                .fillMaxWidth(),
            trailingIcon = {
                IconButton(onClick = {

                    DatePickerDialog(
                        context,
                        { _, year, month, day ->
                            birthDate = "%02d/%02d/%04d".format(
                                day,
                                month + 1,
                                year
                            )
                        },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)
                    ).show()

                }) {
                    Icon(Icons.Default.DateRange, contentDescription = null)
                }
            }
        )

        var expanded by remember { mutableStateOf(false) }

        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded }
        ) {
            OutlinedTextField(
                value = gender,
                onValueChange = {},
                readOnly = true,
                label = { Text("Género") },
                modifier = Modifier.menuAnchor().fillMaxWidth()
            )

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                listOf("Hombre", "Mujer", "Otros").forEach {
                    DropdownMenuItem(
                        text = { Text(it) },
                        onClick = {
                            gender = it
                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                coroutineScope.launch {
                    val updatedUser = user!!.copy(
                        password = password,
                        birthDate = birthDate,
                        gender = gender
                    )

                    dao.updateUser(updatedUser)

                    navController.popBackStack()
                }
            }
        ) {
            Text("Guardar cambios")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Cerrar sesión",
            color = MaterialTheme.colorScheme.error, // rojo del tema
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .clickable {

                    // 🔥 borrar sesión
                    prefs.edit().remove("current_user").apply()

                    // 🔥 redirigir a Register
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0)
                    }
                },
            style = MaterialTheme.typography.bodyLarge
        )
    }
}