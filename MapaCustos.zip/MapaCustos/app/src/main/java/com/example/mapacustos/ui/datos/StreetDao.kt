package com.example.mapacustos.ui.datos

import androidx.room.*

@Dao
interface StreetDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStreet(street: StreetEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(streets: List<StreetEntity>)

    @Query("SELECT * FROM streets")
    suspend fun getAllStreets(): List<StreetEntity>
    @Query("SELECT * FROM streets WHERE name = :streetName LIMIT 1")
    suspend fun getStreetByName(streetName: String): StreetEntity?

    @Query("SELECT COUNT(*) FROM streets")
    suspend fun countStreets(): Int

}