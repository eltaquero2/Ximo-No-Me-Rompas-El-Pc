package com.example.mapacustos.ui.datos

object Routes {
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val MAP = "map"
}
