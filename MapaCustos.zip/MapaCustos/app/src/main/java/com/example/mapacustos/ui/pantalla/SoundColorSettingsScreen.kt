package com.example.mapacustos.ui.pantalla

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.mapacustos.ui.datos.ColorPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.shadow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundColorSettingsScreen(navController: NavController) {

    // Contexto de Android necesario para acceder a almacenamiento, preferencias, etc.
    val context = LocalContext.current


    /* =====================================================
       CONFIGURACIÓN DE SONIDO
       ===================================================== */

    // Sonido cuando el usuario entra en zona de peligro nivel 1
    var playLevel1 by remember { mutableStateOf(true) }

    // Sonido cuando el usuario entra en zona de peligro nivel 2
    var playLevel2 by remember { mutableStateOf(true) }

    // Vibración cuando ocurre una alerta
    var vibrate by remember { mutableStateOf(true) }



    /* =====================================================
       CONFIGURACIÓN DE COLORES
       ===================================================== */

    // Flujo de colores guardados en DataStore
    val colorsFlow = ColorPreferences.getColors(context)

    // Recogemos los colores guardados (hex)
    val savedColors by colorsFlow.collectAsState(
        initial = Triple("#FFFF00", "#FFA500", "#FF0000")
    )

    // Colores actuales en formato Compose Color
    var colorLevel1 by remember { mutableStateOf(Color.Yellow) }
    var colorLevel2 by remember { mutableStateOf(Color(0xFFFFA500)) }
    var colorLevel3 by remember { mutableStateOf(Color.Red) }


    /*
    Cuando cambian los colores guardados en DataStore,
    actualizamos los colores visibles en la UI
     */
    LaunchedEffect(savedColors) {
        colorLevel1 = Color(android.graphics.Color.parseColor(savedColors.first))
        colorLevel2 = Color(android.graphics.Color.parseColor(savedColors.second))
        colorLevel3 = Color(android.graphics.Color.parseColor(savedColors.third))
    }


    // Controla si se muestra el diálogo del selector de color
    var showDialog by remember { mutableStateOf(false) }

    // Nivel seleccionado actualmente para editar color
    var selectedLevel by remember { mutableStateOf(1) }



    /* =====================================================
       INTERFAZ PRINCIPAL
       ===================================================== */

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Sonido y Color") })
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {

            /* ================= SECCIÓN SONIDO ================= */

            Text(
                "Editar Sonido",
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(Modifier.height(20.dp))

            // Interruptor sonido nivel 1
            SoundItem("Nivel 1", playLevel1) { playLevel1 = it }

            Spacer(Modifier.height(16.dp))

            // Interruptor sonido nivel 2
            SoundItem("Nivel 2", playLevel2) { playLevel2 = it }

            Spacer(Modifier.height(16.dp))

            // Interruptor vibración
            SoundItem("Vibración", vibrate) { vibrate = it }



            // Separación visual entre sonido y color
            Spacer(Modifier.height(40.dp))



            /* ================= SECCIÓN COLOR ================= */

            Text(
                "Editar Color",
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(Modifier.height(24.dp))

            // Cajas para editar colores de cada nivel
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {

                ColorBoxFigma("NV 1", colorLevel1) {
                    selectedLevel = 1
                    showDialog = true
                }

                ColorBoxFigma("NV 2", colorLevel2) {
                    selectedLevel = 2
                    showDialog = true
                }

                ColorBoxFigma("NV 3", colorLevel3) {
                    selectedLevel = 3
                    showDialog = true
                }
            }

            Spacer(Modifier.height(30.dp))



            /* ================= BOTÓN GUARDAR ================= */

            Button(
                onClick = {

                    /*
                    Guardar colores en DataStore
                     */
                    CoroutineScope(Dispatchers.IO).launch {
                        ColorPreferences.saveColors(
                            context,
                            colorToHex(colorLevel1),
                            colorToHex(colorLevel2),
                            colorToHex(colorLevel3)
                        )
                    }

                    /*
                    Guardar también en SharedPreferences
                    para que el mapa pueda acceder rápido
                     */
                    context.getSharedPreferences("color_cache", Context.MODE_PRIVATE)
                        .edit()
                        .putString("color_l1", colorToHex(colorLevel1))
                        .putString("color_l2", colorToHex(colorLevel2))
                        .putString("color_l3", colorToHex(colorLevel3))
                        .apply()
                },

                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),

                shape = RoundedCornerShape(30.dp),

                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
            ) {

                // Botón con gradiente morado
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.horizontalGradient(
                                listOf(
                                    Color(0xFF7B00FF),
                                    Color(0xFFB000FF)
                                )
                            ),
                            shape = RoundedCornerShape(30.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Guardar cambios", color = Color.White)
                }
            }
        }
    }



    /* =====================================================
       DIÁLOGO EDITOR DE COLOR
       ===================================================== */

    if (showDialog) {

        // Color actual dependiendo del nivel seleccionado
        val currentColor = when (selectedLevel) {
            1 -> colorLevel1
            2 -> colorLevel2
            else -> colorLevel3
        }

        // Convertimos el color a RGB editable
        var red by remember { mutableStateOf((currentColor.red * 255).toInt()) }
        var green by remember { mutableStateOf((currentColor.green * 255).toInt()) }
        var blue by remember { mutableStateOf((currentColor.blue * 255).toInt()) }

        AlertDialog(
            onDismissRequest = { showDialog = false },
            confirmButton = {},
            shape = RoundedCornerShape(30.dp),
            containerColor = Color(0xFFF5F5F5),

            text = {

                Column(horizontalAlignment = Alignment.CenterHorizontally) {

                    // Título del diálogo
                    Text(
                        "Editar NV $selectedLevel",
                        style = MaterialTheme.typography.titleMedium
                    )

                    Spacer(Modifier.height(24.dp))


                    /*
                    Vista previa del color
                     */
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(28.dp))
                            .background(Color(red, green, blue))
                    )

                    Spacer(Modifier.height(30.dp))


                    /*
                    Sliders RGB
                     */

                    RGBSlider("R", red) { red = it }
                    RGBSlider("G", green) { green = it }
                    RGBSlider("B", blue) { blue = it }

                    Spacer(Modifier.height(24.dp))


                    /*
                    BOTÓN RESTABLECER COLOR
                     */
                    Button(
                        onClick = {

                            val defaultColor = when (selectedLevel) {
                                1 -> Color.Yellow
                                2 -> Color(0xFFFFA500)
                                else -> Color.Red
                            }

                            red = (defaultColor.red * 255).toInt()
                            green = (defaultColor.green * 255).toInt()
                            blue = (defaultColor.blue * 255).toInt()
                        },

                        modifier = Modifier
                            .fillMaxWidth()
                            .height(55.dp),

                        shape = RoundedCornerShape(28.dp),

                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFDADADA)
                        )
                    ) {
                        Text("Restablecer color", color = Color(0xFF7B00FF))
                    }

                    Spacer(Modifier.height(16.dp))


                    /*
                    BOTÓN ACEPTAR
                     */
                    Button(
                        onClick = {

                            val newColor = Color(red, green, blue)

                            when (selectedLevel) {
                                1 -> colorLevel1 = newColor
                                2 -> colorLevel2 = newColor
                                3 -> colorLevel3 = newColor
                            }

                            showDialog = false
                        },

                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp),

                        shape = RoundedCornerShape(30.dp),

                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                    ) {

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    brush = Brush.horizontalGradient(
                                        listOf(
                                            Color(0xFF7B00FF),
                                            Color(0xFFB000FF)
                                        )
                                    ),
                                    shape = RoundedCornerShape(30.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Aceptar", color = Color.White)
                        }
                    }
                }
            }
        )
    }
}

// Caja simple que muestra un color editable
@Composable
fun ColorBox(title: String, color: Color, onClick: () -> Unit) {

    Column(horizontalAlignment = Alignment.CenterHorizontally) {

        Text(title)

        Spacer(Modifier.height(8.dp))

        // Cuadro de color clicable
        Box(
            modifier = Modifier
                .size(70.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(color)
                .clickable { onClick() }
        )
    }
}

// Convierte un Color de Compose a formato hexadecimal (#RRGGBB)
fun colorToHex(color: Color): String {
    return String.format(
        "#%02X%02X%02X",
        (color.red * 255).toInt(),
        (color.green * 255).toInt(),
        (color.blue * 255).toInt()
    )
}

// Tarjeta con interruptor para activar/desactivar sonido
@Composable
fun SoundItem(title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF2F2F2))
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 18.dp),

            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Text(title)

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange
            )
        }
    }
}

// Caja de color estilo Figma (más grande y con sombra)
@Composable
fun ColorBoxFigma(title: String, color: Color, onClick: () -> Unit) {

    Column(horizontalAlignment = Alignment.CenterHorizontally) {

        Box(
            modifier = Modifier
                .size(110.dp)
                .shadow(
                    elevation = 12.dp,
                    shape = RoundedCornerShape(28.dp),
                    clip = false
                )
                .clip(RoundedCornerShape(28.dp))
                .background(color)
                .clickable { onClick() }
        )

        Spacer(Modifier.height(12.dp))

        Text(title)
    }
}

// Slider que permite modificar un valor RGB (0-255)
@Composable
fun RGBSlider(label: String, value: Int, onChange: (Int) -> Unit) {

    // Muestra valor actual
    Text("$label: $value")

    Slider(
        value = value.toFloat(),

        // Cambia valor al mover slider
        onValueChange = { onChange(it.toInt()) },

        // Rango RGB
        valueRange = 0f..255f,

        // Colores personalizados del slider
        colors = SliderDefaults.colors(
            thumbColor = Color(0xFF7B00FF),
            activeTrackColor = Color(0xFFB000FF)
        )
    )

    Spacer(Modifier.height(10.dp))
}