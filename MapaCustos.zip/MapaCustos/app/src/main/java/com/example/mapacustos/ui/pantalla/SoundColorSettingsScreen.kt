package com.example.mapacustos.ui.pantalla

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.mapacustos.ui.datos.ColorPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.shadow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundColorSettingsScreen(navController: NavController) {

    val context = LocalContext.current

    // ================= SONIDO =================
    var playLevel1 by remember { mutableStateOf(true) }
    var playLevel2 by remember { mutableStateOf(true) }
    var vibrate by remember { mutableStateOf(true) }

    // ================= COLORES =================
    val colorsFlow = ColorPreferences.getColors(context)
    val savedColors by colorsFlow.collectAsState(
        initial = Triple("#FFFF00", "#FFA500", "#FF0000")
    )

    var colorLevel1 by remember { mutableStateOf(Color.Yellow) }
    var colorLevel2 by remember { mutableStateOf(Color(0xFFFFA500)) }
    var colorLevel3 by remember { mutableStateOf(Color.Red) }

    LaunchedEffect(savedColors) {
        colorLevel1 = Color(android.graphics.Color.parseColor(savedColors.first))
        colorLevel2 = Color(android.graphics.Color.parseColor(savedColors.second))
        colorLevel3 = Color(android.graphics.Color.parseColor(savedColors.third))
    }

    var showDialog by remember { mutableStateOf(false) }
    var selectedLevel by remember { mutableStateOf(1) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Sonido y Color") })
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {

            Text(
                "Editar Sonido",
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(Modifier.height(20.dp))

            SoundItem("Nivel 1", playLevel1) { playLevel1 = it }
            Spacer(Modifier.height(16.dp))
            SoundItem("Nivel 2", playLevel2) { playLevel2 = it }
            Spacer(Modifier.height(16.dp))
            SoundItem("Vibración", vibrate) { vibrate = it }

            // 🔥 SEPARACIÓN GRANDE
            Spacer(Modifier.height(40.dp))

            Text(
                "Editar Color",
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {

                ColorBoxFigma("NV 1", colorLevel1) {
                    selectedLevel = 1
                    showDialog = true
                }

                ColorBoxFigma("NV 2", colorLevel2) {
                    selectedLevel = 2
                    showDialog = true
                }

                ColorBoxFigma("NV 3", colorLevel3) {
                    selectedLevel = 3
                    showDialog = true
                }
            }

            Spacer(Modifier.height(30.dp))

            Button(
                onClick = {
                    CoroutineScope(Dispatchers.IO).launch {
                        ColorPreferences.saveColors(
                            context,
                            colorToHex(colorLevel1),
                            colorToHex(colorLevel2),
                            colorToHex(colorLevel3)
                        )
                    }

                    context.getSharedPreferences("color_cache", Context.MODE_PRIVATE)
                        .edit()
                        .putString("color_l1", colorToHex(colorLevel1))
                        .putString("color_l2", colorToHex(colorLevel2))
                        .putString("color_l3", colorToHex(colorLevel3))
                        .apply()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),
                shape = RoundedCornerShape(30.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.horizontalGradient(
                                listOf(
                                    Color(0xFF7B00FF),
                                    Color(0xFFB000FF)
                                )
                            ),
                            shape = RoundedCornerShape(30.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Guardar cambios", color = Color.White)
                }
            }
        }
    }

    // ================= DIALOGO =================

    if (showDialog) {

        val currentColor = when (selectedLevel) {
            1 -> colorLevel1
            2 -> colorLevel2
            else -> colorLevel3
        }

        var red by remember { mutableStateOf((currentColor.red * 255).toInt()) }
        var green by remember { mutableStateOf((currentColor.green * 255).toInt()) }
        var blue by remember { mutableStateOf((currentColor.blue * 255).toInt()) }

        AlertDialog(
            onDismissRequest = { showDialog = false },
            confirmButton = {},
            shape = RoundedCornerShape(30.dp),
            containerColor = Color(0xFFF5F5F5),
            text = {

                Column(horizontalAlignment = Alignment.CenterHorizontally) {

                    Text(
                        "Editar NV $selectedLevel",
                        style = MaterialTheme.typography.titleMedium
                    )

                    Spacer(Modifier.height(24.dp))

                    // Rectángulo grande arriba
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(28.dp))
                            .background(Color(red, green, blue))
                    )

                    Spacer(Modifier.height(30.dp))

                    RGBSlider("R", red) { red = it }
                    RGBSlider("G", green) { green = it }
                    RGBSlider("B", blue) { blue = it }

                    Spacer(Modifier.height(24.dp))

                    // Restablecer
                    Button(
                        onClick = {
                            val defaultColor = when (selectedLevel) {
                                1 -> Color.Yellow
                                2 -> Color(0xFFFFA500)
                                else -> Color.Red
                            }

                            red = (defaultColor.red * 255).toInt()
                            green = (defaultColor.green * 255).toInt()
                            blue = (defaultColor.blue * 255).toInt()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(55.dp),
                        shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFDADADA)
                        )
                    ) {
                        Text("Restablecer color", color = Color(0xFF7B00FF))
                    }

                    Spacer(Modifier.height(16.dp))

                    // Aceptar morado
                    Button(
                        onClick = { /* aceptar */ },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp),
                        shape = RoundedCornerShape(30.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent
                        )
                    ) {
                        Button(
                            onClick = {
                                val newColor = Color(red, green, blue)

                                when (selectedLevel) {
                                    1 -> colorLevel1 = newColor
                                    2 -> colorLevel2 = newColor
                                    3 -> colorLevel3 = newColor
                                }

                                showDialog = false
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(60.dp),
                            shape = RoundedCornerShape(30.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        brush = Brush.horizontalGradient(
                                            listOf(
                                                Color(0xFF7B00FF),
                                                Color(0xFFB000FF)
                                            )
                                        ),
                                        shape = RoundedCornerShape(30.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Aceptar", color = Color.White)
                            }
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun ColorBox(title: String, color: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {

        Text(title)

        Spacer(Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .size(70.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(color)
                .clickable { onClick() }
        )
    }
}

fun colorToHex(color: Color): String {
    return String.format(
        "#%02X%02X%02X",
        (color.red * 255).toInt(),
        (color.green * 255).toInt(),
        (color.blue * 255).toInt()
    )
}

@Composable
fun SoundItem(title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF2F2F2))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title)

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange
            )
        }
    }
}

@Composable
fun ColorBoxFigma(title: String, color: Color, onClick: () -> Unit) {

    Column(horizontalAlignment = Alignment.CenterHorizontally) {

        Box(
            modifier = Modifier
                .size(110.dp)
                .shadow(
                    elevation = 12.dp,
                    shape = RoundedCornerShape(28.dp),
                    clip = false
                )
                .clip(RoundedCornerShape(28.dp))
                .background(color)
                .clickable { onClick() }
        )

        Spacer(Modifier.height(12.dp))

        Text(title)
    }
}

@Composable
fun RGBSlider(label: String, value: Int, onChange: (Int) -> Unit) {

    Text("$label: $value")

    Slider(
        value = value.toFloat(),
        onValueChange = { onChange(it.toInt()) },
        valueRange = 0f..255f,
        colors = SliderDefaults.colors(
            thumbColor = Color(0xFF7B00FF),
            activeTrackColor = Color(0xFFB000FF)
        )
    )

    Spacer(Modifier.height(10.dp))
}