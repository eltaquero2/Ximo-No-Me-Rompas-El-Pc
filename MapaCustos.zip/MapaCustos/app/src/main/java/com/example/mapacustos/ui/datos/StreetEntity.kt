package com.example.mapacustos.ui.datos

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "streets")
data class StreetEntity(

    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val name: String,

    val dangerLevel: Int = 0,
    val includesViolation: Boolean = false,
    val includesViolence: Boolean = false,

    val geoJson: String
)